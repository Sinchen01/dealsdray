import 'package:flutter/material.dart';
import 'otp_verification_screen.dart'; // Import the OTP verification screen

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _isPhoneSelected = true; // Toggle between Phone and Email login
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  // Predefined user credentials for validation
  final String validMobileNumber = "9011470243";
  final String validEmail = "muhammedrafnasvk@gmail.com";
  final String validPassword = "1234Rafnas";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('DealsDray'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context); // Handle back navigation
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start, // Align to the top
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 40), // Adjust the height to pull content up
            // DealsDray logo at the top
            Image.network(
              'https://play-lh.googleusercontent.com/Im3CE-kmZJmZMC8pkhpCj7tGznPI6LC1EjhaTJ3E6Cdh_mgW5VxF_joZK31XWwZPmkT5=w240-h480-rw',
              width: 120, // Adjust width as needed
              height: 120, // Adjust height as needed
            ),
            const SizedBox(height: 10), // Reduced space after the logo

            // Text for welcome message
            const Text(
              'Glad to see you!',
              style: TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),

            // Toggle between Phone and Email login
            ToggleButtons(
              onPressed: (int index) {
                setState(() {
                  _isPhoneSelected = index == 0;
                });
              },
              isSelected: [_isPhoneSelected, !_isPhoneSelected],
              children: const [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: Text('Phone'),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: Text('Email'),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Phone input and Password input if Phone is selected
            if (_isPhoneSelected)
              Column(
                children: [
                  TextFormField(
                    controller: _phoneController,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(labelText: 'Phone'),
                  ),
                  const SizedBox(height: 10),
                  TextFormField(
                    controller: _passwordController,
                    obscureText: true,
                    decoration: const InputDecoration(labelText: 'Password'),
                  ),
                ],
              ),

            // Email input and Password input if Email is selected
            if (!_isPhoneSelected)
              Column(
                children: [
                  TextFormField(
                    controller: _emailController,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(labelText: 'Email'),
                  ),
                  const SizedBox(height: 10),
                  TextFormField(
                    controller: _passwordController,
                    obscureText: true,
                    decoration: const InputDecoration(labelText: 'Password'),
                  ),
                ],
              ),
            const SizedBox(height: 20),

            // Button to proceed with login
            ElevatedButton(
              onPressed: () {
                // Validate credentials
                if (_isPhoneSelected &&
                    _phoneController.text == validMobileNumber &&
                    _passwordController.text == validPassword) {
                  // Navigate to OTP Verification Screen
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const OtpVerificationScreen()),
                  );
                } else if (!_isPhoneSelected &&
                    _emailController.text == validEmail &&
                    _passwordController.text == validPassword) {
                  // Navigate to OTP Verification Screen
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const OtpVerificationScreen()),
                  );
                } else {
                  // Show error if credentials are not valid
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                        content: Text('Please enter correct password')),
                  );
                }
              },
              child: const Text('SEND CODE'),
            ),
          ],
        ),
      ),
    );
  }
}
