import 'package:flutter/material.dart';
import 'credentials_screen.dart'; // Import the credentials screen

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Navigate to CredentialsScreen after 2 seconds
    Future.delayed(const Duration(seconds: 2), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const CredentialsScreen()),
      );
    });

    return Scaffold(
      body: SizedBox.expand(
        child: Image.network(
          'https://play-lh.googleusercontent.com/cFqw-mWtcFBnR8lYHdHfj1VbDh7PQELCGk-3eGaMgTTQtrAztWg36DzAB4qyNI3C5I1M=w2560-h1440-rw', // New image link
          fit: BoxFit.cover, // Makes the image cover the entire screen
        ),
      ),
    );
  }
}
