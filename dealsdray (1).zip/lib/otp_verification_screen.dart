import 'dart:async';
import 'package:flutter/material.dart';
import 'home_screen.dart'; // Import the Home Screen

class OtpVerificationScreen extends StatefulWidget {
  const OtpVerificationScreen({super.key});

  @override
  State<OtpVerificationScreen> createState() => _OtpVerificationScreenState();
}

class _OtpVerificationScreenState extends State<OtpVerificationScreen> {
  final TextEditingController _otpController1 = TextEditingController();
  final TextEditingController _otpController2 = TextEditingController();
  final TextEditingController _otpController3 = TextEditingController();
  final TextEditingController _otpController4 = TextEditingController();

  late Timer _timer;
  int _start = 120; // Timer starts at 120 seconds (2 minutes)

  @override
  void initState() {
    super.initState();
    startTimer();
  }

  @override
  void dispose() {
    _timer.cancel(); // Ensure the timer is canceled when the widget is disposed
    super.dispose();
  }

  void startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_start == 0) {
        setState(() {
          timer.cancel(); // Stop the timer when it reaches 0
        });
      } else {
        setState(() {
          _start--; // Decrease the timer every second
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('OTP Verification'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Image showing a mobile with OTP icon
              Image.network(
                'https://thumbs.dreamstime.com/z/mobile-phone-showing-one-time-password-vector-icon-mobile-phone-showing-one-time-password-vector-icon-filled-flat-sign-322580090.jpg?ct=jpeg',
                width: 150,
                height: 150,
              ),
              const SizedBox(height: 20),
              const Text(
                'We have sent a unique OTP number to your mobile +91-9765232817',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  OtpInput(
                      controller: _otpController1,
                      onChanged: (value) {
                        if (value.isNotEmpty) {
                          FocusScope.of(context)
                              .nextFocus(); // Move to next field
                        }
                      }),
                  const SizedBox(width: 10),
                  OtpInput(
                      controller: _otpController2,
                      onChanged: (value) {
                        if (value.isNotEmpty) {
                          FocusScope.of(context)
                              .nextFocus(); // Move to next field
                        }
                      }),
                  const SizedBox(width: 10),
                  OtpInput(
                      controller: _otpController3,
                      onChanged: (value) {
                        if (value.isNotEmpty) {
                          FocusScope.of(context)
                              .nextFocus(); // Move to next field
                        }
                      }),
                  const SizedBox(width: 10),
                  OtpInput(
                      controller: _otpController4,
                      onChanged: (value) {
                        if (value.isNotEmpty) {
                          FocusScope.of(context)
                              .unfocus(); // Dismiss keyboard on last field
                        }
                      }),
                ],
              ),
              const SizedBox(height: 20),
              // Display the countdown timer
              Text(
                '${(_start ~/ 60).toString().padLeft(2, '0')}:${(_start % 60).toString().padLeft(2, '0')}', // MM:SS format
                style:
                    const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  // Proceed to Home Page after OTP verification
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const HomeScreen()),
                  );
                },
                child: const Text('Submit OTP'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class OtpInput extends StatelessWidget {
  final TextEditingController controller;
  final ValueChanged<String> onChanged; // Callback for when the value changes

  const OtpInput(
      {required this.controller, required this.onChanged, super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 60, // Increased width for bigger size
      height: 60, // Increased height for bigger size
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Center(
        child: TextFormField(
          controller: controller,
          keyboardType: TextInputType.number,
          textAlign: TextAlign.center,
          maxLength: 1,
          onChanged: onChanged, // Call the onChanged callback
          decoration: const InputDecoration(counterText: ''),
        ),
      ),
    );
  }
}
