import 'package:flutter/material.dart';
import 'custom_drawer.dart'; // Import your custom drawer

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('DealsDray'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              // Handle search functionality
            },
          ),
          IconButton(
            icon: const Icon(Icons.notifications),
            onPressed: () {
              // Handle notifications
            },
          ),
        ],
      ),
      drawer: const CustomDrawer(), // Add your custom drawer
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Banner section
            _buildBannerSection(),

            // KYC Pending section
            _buildKycPendingSection(),

            // Category icons
            _buildCategoryIcons(),

            // Exclusive for you section
            _buildExclusiveForYouSection(),
          ],
        ),
      ),
      bottomNavigationBar:
          _buildBottomNavigationBar(), // Add a bottom navigation bar
    );
  }

  // Widget for banner section
  Widget _buildBannerSection() {
    return Row(
      children: [
        Expanded(
          child: Image.network(
            'https://example.com/banner1.jpg', // Replace with your banner image URL
            height: 200,
            fit: BoxFit.cover,
          ),
        ),
        const SizedBox(width: 8), // Space between banners
        Expanded(
          child: Image.network(
            'https://example.com/banner2.jpg', // Replace with your banner image URL
            height: 200,
            fit: BoxFit.cover,
          ),
        ),
      ],
    );
  }

  // Widget for KYC Pending section
  Widget _buildKycPendingSection() {
    return Container(
      color: Colors.yellow[100],
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          const Icon(Icons.info),
          const SizedBox(width: 8),
          const Text(
            'KYC Pending',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const Spacer(),
          TextButton(
            onPressed: () {
              // Handle KYC process
            },
            child: const Text('Click Here'),
          ),
        ],
      ),
    );
  }

  // Widget for category icons
  Widget _buildCategoryIcons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: const [
        CategoryIcon(Icons.mobile_friendly, 'Mobile'),
        CategoryIcon(Icons.laptop, 'Laptop'),
        CategoryIcon(Icons.camera_alt, 'Camera'),
        CategoryIcon(Icons.lightbulb, 'LED'),
      ],
    );
  }

  // Widget for exclusive products section
  Widget _buildExclusiveForYouSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'EXCLUSIVE FOR YOU',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Row(
            children: const [
              ProductCard(
                imageUrl: 'https://example.com/product1.jpg',
                title: 'Nokia 8.1 (iron, 64 GB)',
                discount: '32',
                price: '616',
              ),
              SizedBox(width: 16),
              ProductCard(
                imageUrl: 'https://example.com/product2.jpg',
                title: 'Reck',
                discount: '14',
                price: '08.00',
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Widget for bottom navigation bar
  BottomNavigationBar _buildBottomNavigationBar() {
    return BottomNavigationBar(
      currentIndex: 0, // Adjust this index based on the selected page
      onTap: (index) {
        // Handle bottom navigation item taps
      },
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.home),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.category),
          label: 'Categories',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.local_offer),
          label: 'Deals',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.shopping_cart),
          label: 'Cart',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person),
          label: 'Profile',
        ),
      ],
    );
  }
}

// Reusable widgets for category icons and product cards
class CategoryIcon extends StatelessWidget {
  final IconData icon;
  final String label;

  const CategoryIcon(this.icon, this.label, {super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, size: 40),
        Text(label),
      ],
    );
  }
}

class ProductCard extends StatelessWidget {
  final String imageUrl;
  final String title;
  final String discount;
  final String price;

  const ProductCard({
    required this.imageUrl,
    required this.title,
    required this.discount,
    required this.price,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Image.network(imageUrl, width: 100, height: 100),
        Text(title),
        Text(
          '$discount% OFF',
          style: const TextStyle(color: Colors.red),
        ),
        Text(
          '₹$price',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}
