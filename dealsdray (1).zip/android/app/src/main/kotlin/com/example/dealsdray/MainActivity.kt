package com.example.dealsdray

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
